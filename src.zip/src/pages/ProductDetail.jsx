import { useParams, Link } from 'react-router-dom'
import { useState, useEffect, useRef } from 'react'
import { useCart } from '../context/CartContext'
import { Minus, Plus, ShoppingBag, Truck, RefreshCw, Shield } from 'lucide-react'
import LazyImage from '../components/LazyImage'
import { useToast } from '../context/ToastContext'
import useGsapContext from '../hooks/useGsapContext'
import { gsap, EASE } from '../lib/gsap'
import { useStore, loadFullProduct } from '../lib/store'


export default function ProductDetail() {
  const { id } = useParams()
  const { addToCart } = useCart()
  const { toast } = useToast()
  const [quantity, setQuantity] = useState(1)
  const [currentImage, setCurrentImage] = useState(0)
  const { products } = useStore()
  const [size, setSize] = useState('')
  const [sizeError, setSizeError] = useState(false)
  const [color, setColor] = useState('')
  const [colorError, setColorError] = useState(false)
  const [added, setAdded] = useState(false)
  const infoRef = useRef(null)
  const ctaRef = useRef(null)

  const product = products.find((p) => String(p.id) === String(id))
  const sizes = product?.sizes || []
  const colors = product?.colors || []
  const outOfStock = product?.inStock === false

  // The list only carries the first photo (so pages load fast) — pull the
  // full gallery for this product in the background.
  useEffect(() => { loadFullProduct(id) }, [id])
  useEffect(() => { setSize(''); setSizeError(false); setColor(''); setColorError(false) }, [id])

  // Entrance animation for the info column once the product is known.
  useGsapContext(() => {
    if (!product || !infoRef.current) return
    gsap.fromTo(
      infoRef.current.children,
      { opacity: 0, y: 18 },
      { opacity: 1, y: 0, duration: 0.5, stagger: 0.06, ease: EASE }
    )
  }, [product?.id], infoRef)

  if (!product) {
    return (
      <div className="container mx-auto px-4 py-32 text-center">
        <p className="text-gray-400 text-sm uppercase tracking-widest mb-6">Product not found</p>
        <Link to="/shop" className="inline-flex items-center gap-2 text-sm font-bold uppercase tracking-widest underline underline-offset-4">
          Back to Shop
        </Link>
      </div>
    )
  }

  const handleAddToCart = () => {
    if (outOfStock) return
    if (sizes.length > 0 && !size) {
      setSizeError(true)
      toast('Please select a size first.', { type: 'error' })
      return
    }
    if (colors.length > 0 && !color) {
      setColorError(true)
      toast('Please select a colour first.', { type: 'error' })
      return
    }
    addToCart(product, size, quantity, color)
    setAdded(true)
    toast(`Added ${quantity} × ${product.name}${size ? ` (size ${size})` : ''}${color ? ` (${color})` : ''} to your bag.`, { type: 'success' })
    if (ctaRef.current) {
      gsap.fromTo(ctaRef.current, { scale: 0.96 }, { scale: 1, duration: 0.35, ease: 'back.out(2.5)' })
    }
    setTimeout(() => setAdded(false), 2000)
  }

  return (
    <div>
      {/* Breadcrumb */}
      <div className="border-b border-gray-100">
        <div className="container mx-auto px-4 sm:px-6 py-3">
          <nav className="flex items-center gap-2 text-[10px] uppercase tracking-[0.14em] text-gray-400">
            <Link to="/" className="hover:text-black transition-colors">Home</Link>
            <span>/</span>
            <Link to="/shop" className="hover:text-black transition-colors">Shop</Link>
            <span>/</span>
            <span className="text-black font-medium truncate max-w-[180px]">{product.name}</span>
          </nav>
        </div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 py-8 lg:py-14">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-16">

          {/* Images */}
          <div className="space-y-3">
            <div className="relative aspect-[4/5] overflow-hidden">
              <LazyImage
                key={currentImage}
                src={product.images[currentImage]}
                alt={product.name}
                className="h-full w-full"
                eager
              />
              <span className="absolute top-4 left-4 z-10 bg-[#0D0F1C] text-[#C9A24B] text-[9px] font-bold uppercase tracking-[0.2em] px-3 py-1.5">
                {product.category}
              </span>
            </div>
            {product.images.length > 1 && (
              <div className="flex gap-2 overflow-x-auto">
                {product.images.map((img, i) => (
                  <button
                    key={i}
                    onClick={() => setCurrentImage(i)}
                    className={`shrink-0 w-16 h-20 overflow-hidden border-2 transition-colors ${
                      currentImage === i ? 'border-[#C9A24B]' : 'border-transparent'
                    }`}
                  >
                    <LazyImage src={img} alt="" className="h-full w-full" eager />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Info — sticky on large screens */}
          <div ref={infoRef} className="lg:sticky lg:top-24 lg:self-start space-y-6">
            <div>
              <p className="text-[10px] text-[#C9A24B] uppercase tracking-[0.2em] font-semibold mb-1.5">{product.category}</p>
              <h1 className="text-2xl sm:text-3xl font-bold uppercase tracking-[-0.01em] leading-tight mb-3">
                {product.name}
              </h1>
              <p className="text-2xl sm:text-3xl font-bold">₦{parseFloat(product.price).toLocaleString()}</p>
            </div>

            <div className="border-t border-gray-100 pt-5">
              <p className="text-gray-600 text-sm leading-relaxed">{product.description}</p>
            </div>

            {/* Size — required before adding to bag */}
            {sizes.length > 0 && (
              <div>
                <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-gray-500 mb-2">
                  Size {size && <span className="text-black">· {size}</span>}
                </p>
                <div className="flex flex-wrap gap-2">
                  {sizes.map((s) => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => { setSize(s); setSizeError(false) }}
                      aria-pressed={size === s}
                      className={`min-w-[3rem] h-11 px-4 text-sm font-semibold border transition-colors ${
                        size === s ? 'bg-[#0D0F1C] text-white border-[#0D0F1C]' : 'bg-white text-gray-700 border-gray-200 hover:border-black'
                      }`}
                    >
                      {s}
                    </button>
                  ))}
                </div>
                {sizeError && <p className="mt-2 text-xs font-medium text-red-500">Please select a size to continue.</p>}
              </div>
            )}

            {/* Colour — required before adding to bag */}
            {colors.length > 0 && (
              <div>
                <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-gray-500 mb-2">
                  Colour {color && <span className="text-black">· {color}</span>}
                </p>
                <div className="flex flex-wrap gap-2">
                  {colors.map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => { setColor(c); setColorError(false) }}
                      aria-pressed={color === c}
                      className={`min-w-[3rem] h-11 px-4 text-sm font-semibold border transition-colors ${
                        color === c ? 'bg-[#0D0F1C] text-white border-[#0D0F1C]' : 'bg-white text-gray-700 border-gray-200 hover:border-black'
                      }`}
                    >
                      {c}
                    </button>
                  ))}
                </div>
                {colorError && <p className="mt-2 text-xs font-medium text-red-500">Please select a colour to continue.</p>}
              </div>
            )}

            {/* Quantity */}
            <div className="flex items-center gap-4">
              <span className="text-[10px] font-bold uppercase tracking-[0.18em] text-gray-500">Qty</span>
              <div className="flex items-center border border-gray-200 rounded">
                <button
                  aria-label="Decrease quantity"
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-10 h-10 flex items-center justify-center hover:bg-gray-50 active:scale-90 transition-all"
                >
                  <Minus size={14} />
                </button>
                <span className="w-10 text-center text-sm font-semibold">{quantity}</span>
                <button
                  aria-label="Increase quantity"
                  onClick={() => setQuantity(quantity + 1)}
                  className="w-10 h-10 flex items-center justify-center hover:bg-gray-50 active:scale-90 transition-all"
                >
                  <Plus size={14} />
                </button>
              </div>
            </div>

            {outOfStock && (
              <p className="text-sm font-semibold text-red-600 bg-red-50 border border-red-200 px-4 py-3">
                This item is currently out of stock and can't be purchased right now.
              </p>
            )}

            {/* CTA */}
            <button
              ref={ctaRef}
              onClick={handleAddToCart}
              disabled={outOfStock}
              className={`w-full py-4 sm:py-5 font-bold uppercase tracking-[0.14em] text-sm flex items-center justify-center gap-3 transition-all duration-300 active:scale-[0.98] ${
                outOfStock
                  ? 'bg-gray-200 text-gray-500 cursor-not-allowed'
                  : added
                  ? 'bg-green-600 text-white'
                  : 'bg-[#0D0F1C] text-white hover:bg-[#C9A24B]'
              }`}
            >
              <ShoppingBag size={18} />
              {outOfStock ? 'Out of Stock' : added ? 'Added to Bag!' : 'Add to Bag'}
            </button>

            {/* Trust badges */}
            <div className="border-t border-gray-100 pt-5 space-y-3">
              {[
                { icon: Truck, text: 'We do not accept clothes that are worn, washed, altered & ale items' },
                { icon: RefreshCw, text: 'We do not do cash refunds, but we will gladly issue you store credit of the same amount' },
                { icon: Shield, text: 'Note: You are responsible for return delivery cahrges' },
              ].map(({ icon: Icon, text }) => (
                <div key={text} className="flex items-center gap-3 text-xs text-gray-500">
                  <Icon size={14} className="text-[#C9A24B] shrink-0" />
                  <span>{text}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
